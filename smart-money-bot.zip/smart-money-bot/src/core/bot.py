"""
core/bot.py
Main orchestrator — ties together scanner, strategy, and risk manager.
"""

import time
import os
from loguru import logger
from dotenv import load_dotenv

from src.exchange.bybit_client import BybitClient
from src.scanner.pair_scanner import PairScanner
from src.strategy.smart_money import SmartMoneyStrategy
from src.risk.risk_manager import RiskManager

load_dotenv()


class SmartMoneyBot:
    def __init__(self):
        self.mode = os.getenv("BOT_MODE", "paper")
        self.scan_interval = int(os.getenv("SCAN_INTERVAL_SECONDS", 60))

        logger.info(f"🤖 SmartMoneyBot starting in {self.mode.upper()} mode")

        self.client = BybitClient()
        self.scanner = PairScanner(self.client)
        self.strategy = SmartMoneyStrategy(self.client)
        self.risk = RiskManager(self.client)

        self.watchlist = []   # Top pairs from scanner
        self.last_scan = 0
        self.scan_every = 300  # Re-scan every 5 minutes

    def run(self):
        """Main bot loop"""
        logger.info("▶️  Bot loop started")
        while True:
            try:
                self._cycle()
                time.sleep(self.scan_interval)
            except KeyboardInterrupt:
                logger.info("🛑 Bot stopped by user")
                break
            except Exception as e:
                logger.error(f"Loop error: {e}")
                time.sleep(10)

    def _cycle(self):
        """One full scan + signal + execution cycle"""

        # Step 1: Refresh watchlist periodically
        now = time.time()
        if not self.watchlist or (now - self.last_scan) > self.scan_every:
            logger.info("🔄 Refreshing pair watchlist...")
            df = self.scanner.scan()
            if not df.empty:
                self.watchlist = df["symbol"].tolist()
                self.last_scan = now
                logger.info(f"📋 Watchlist updated: {self.watchlist[:5]}...")

        if not self.watchlist:
            logger.warning("Empty watchlist, skipping cycle")
            return

        # Step 2: Analyze each pair in watchlist
        for symbol in self.watchlist:
            signal = self.strategy.analyze(symbol)

            if signal.side == "none":
                continue

            logger.info(
                f"📡 Signal: {signal.side.upper()} {symbol} "
                f"(strength: {signal.strength:.0%})"
            )
            for r in signal.reason:
                logger.info(f"   → {r}")

            # Step 3: Risk check
            allowed, reason = self.risk.can_open_position(signal)
            if not allowed:
                logger.info(f"⏭️  Skipping {symbol}: {reason}")
                continue

            # Step 4: Execute
            self._execute(signal)

    def _execute(self, signal):
        """Execute a trade based on signal"""
        contracts = self.risk.calculate_position_size(signal)
        if contracts <= 0:
            return

        if self.mode == "paper":
            logger.info(
                f"📝 [PAPER] Would {signal.side.upper()} {contracts:.6f} {signal.symbol} "
                f"@ {signal.entry_price} | SL: {signal.sl_price} | TP: {signal.tp_price}"
            )
            return

        # Live execution
        order = self.client.place_order(
            symbol=signal.symbol,
            side=signal.side,
            amount=contracts,
            order_type="market"
        )

        if order:
            self.client.set_stop_loss_take_profit(
                symbol=signal.symbol,
                side=signal.side,
                sl_price=signal.sl_price,
                tp_price=signal.tp_price
            )
            self.risk.log_trade(signal, contracts, order)
